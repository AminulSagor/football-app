import 'package:dio/dio.dart' as dio;

import '../../../../core/services/api_client.dart';
import '../../../../core/services/storage_service.dart';
import '../auth_models/auth_models.dart';

class SettingsAuthService {
  final ApiClient _apiClient;
  final StorageService _storageService;

  SettingsAuthService({
    required ApiClient apiClient,
    required StorageService storageService,
  }) : _apiClient = apiClient,
       _storageService = storageService;

  Future<SettingsAuthSessionUiModel?> loadSession(
    SettingsLoadSessionPayloadModel _,
  ) async {
    final token = _storageService.token;

    if (!_storageService.isLoggedIn || token.isEmpty) {
      return null;
    }

    final response = await _apiClient.get<Map<String, dynamic>>('/users/me');

    final responseData = response.data;
    if (responseData == null) {
      throw Exception('empty_response');
    }

    final dataJson = responseData['data'];
    if (dataJson is! Map<String, dynamic>) {
      throw Exception('missing_data');
    }

    final user = SettingsUserUiModel.fromJson(dataJson);

    if (user.fullName.trim().isEmpty || user.email.trim().isEmpty) {
      await _storageService.clearLoggedInData();
      return null;
    }

    await _storageService.setProfileData(
      fullName: user.fullName,
      email: user.email,
      avatarSeed: user.avatarSeed,
      role: user.role,
    );

    return SettingsAuthSessionUiModel(
      token: SettingsAuthTokenUiModel(
        accessToken: token,
        tokenType: _storageService.tokenType,
        expiresIn: _storageService.tokenExpires,
      ),
      user: user,
    );
  }

  Future<SettingsAuthSessionUiModel> signIn(
    SettingsSignInPayloadModel payload,
  ) async {
    final response = await _apiClient.post<Map<String, dynamic>>(
      '/auth/login',
      data: payload.toJson(),
      options: dio.Options(
        headers: <String, dynamic>{'Content-Type': 'application/json'},
        extra: <String, dynamic>{'skipAuth': true},
      ),
    );

    final responseData = response.data;
    if (responseData == null) {
      throw Exception('empty_response');
    }

    final dataJson = responseData['data'];
    if (dataJson is! Map<String, dynamic>) {
      throw Exception('missing_data');
    }

    final session = SettingsAuthSessionUiModel.fromJson(dataJson);
    await _storageService.setLoggedInData(
      session.token.accessToken,
      fullName: session.user.fullName,
      email: session.user.email,
      avatarSeed: session.user.avatarSeed,
      tokenType: session.token.tokenType,
      expiresIn: session.token.expiresIn,
      userId: session.user.id,
      role: session.user.role,
    );
    return session;
  }

  Future<SettingsLogoutUiModel> logout(
    SettingsLogoutPayloadModel payload,
  ) async {
    final hadToken = payload.token.trim().isNotEmpty;
    await Future<void>.delayed(const Duration(milliseconds: 220));
    await _storageService.clearLoggedInData();

    final responseJson = <String, dynamic>{
      'logged_out': true,
      'had_token': hadToken,
    };
    return SettingsLogoutUiModel.fromJson(responseJson);
  }

  Future<SettingsProfileUpdateUiModel> updateProfile(
    SettingsProfileUpdatePayloadModel payload,
  ) async {
    await _apiClient.patch<Map<String, dynamic>>(
      '/users/me/profile',
      data: payload.toProfileJson(),
      options: dio.Options(
        headers: <String, dynamic>{'Content-Type': 'application/json'},
      ),
    );

    if (payload.hasPasswordChanges) {
      await _apiClient.patch<Map<String, dynamic>>(
        '/users/me/password',
        data: payload.toPasswordJson(),
        options: dio.Options(
          headers: <String, dynamic>{'Content-Type': 'application/json'},
        ),
      );
    }

    final meResponse = await _apiClient.get<Map<String, dynamic>>('/users/me');

    final responseData = meResponse.data;
    if (responseData == null) {
      throw Exception('empty_response');
    }

    final dataJson = responseData['data'];
    if (dataJson is! Map<String, dynamic>) {
      throw Exception('missing_data');
    }

    final user = SettingsUserUiModel.fromJson(dataJson);

    await _storageService.setProfileData(
      fullName: user.fullName,
      email: user.email,
      avatarSeed: user.avatarSeed,
      role: user.role,
    );

    return SettingsProfileUpdateUiModel(updated: true, user: user);
  }

  Future<SettingsDeleteAccountUiModel> deleteAccount(
    SettingsDeleteAccountPayloadModel payload,
  ) async {
    await Future<void>.delayed(const Duration(milliseconds: 280));

    final isMatch =
        payload.confirmationName.trim().toLowerCase() ==
        payload.currentUserName.trim().toLowerCase();
    if (!isMatch) {
      throw Exception('delete_account_confirmation_mismatch');
    }

    await _storageService.clearLoggedInData();

    final responseJson = <String, dynamic>{'deleted': true};
    return SettingsDeleteAccountUiModel.fromJson(responseJson);
  }
}
