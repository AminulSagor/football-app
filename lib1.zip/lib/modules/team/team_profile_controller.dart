import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../core/models/following_models.dart';
import '../../core/services/api_client.dart';
import '../../core/services/api_error_handler.dart';
import '../../core/services/following_service.dart';
import '../../core/services/storage_service.dart';
import '../../routes/app_routes.dart';
import '../matches/model/matches_models.dart' hide FootballPlayerStatisticModel;
import '../leagues/model/leagues_models.dart';
import 'team_profile_model.dart';
import 'team_profile_service.dart';

class TeamProfileBinding extends Bindings {
  @override
  void dependencies() {
    if (!Get.isRegistered<FollowingService>()) {
      Get.lazyPut<FollowingService>(
        () => FollowingService(
          apiClient: Get.find<ApiClient>(),
          storageService: Get.find<StorageService>(),
        ),
        fenix: true,
      );
    }
    if (!Get.isRegistered<TeamProfileService>()) {
      Get.lazyPut<TeamProfileService>(
        () => TeamProfileService(apiClient: Get.find<ApiClient>()),
        fenix: true,
      );
    }
    Get.lazyPut<TeamProfileController>(
      () => TeamProfileController(
        followingService: Get.find<FollowingService>(),
        service: Get.find<TeamProfileService>(),
      ),
    );
  }
}

class TeamProfileController extends GetxController {
  TeamProfileController({
    required FollowingService followingService,
    required TeamProfileService service,
  }) : _followingService = followingService,
       _service = service;

  static const int _matchesPageSize = 5;
  static const int _overviewPreviousLimit = 6;

  final FollowingService _followingService;
  final TeamProfileService _service;
  final Rx<TeamProfileViewModel> state = _initialState.obs;

  Worker? _worker;
  int initialTabIndex = 0;
  String _teamId = '33';

  @override
  void onInit() {
    super.onInit();
    _readArguments();
    _syncFollowingState();
    _worker = ever<int>(
      _followingService.revision,
      (_) => _syncFollowingState(),
    );
    _loadInitialData();
  }

  @override
  void onClose() {
    _worker?.dispose();
    super.onClose();
  }

  Future<void> follow() async {
    final payload = FollowEntityPayloadModel(
      entityType: FollowEntityType.team,
      entityId: _teamId,
      entityName: state.value.team.name,
      entityLogo: state.value.team.logoUrl,
      notificationEnabled: true,
    );

    await ApiErrorHandler.handle<FollowingActionUiModel>(
      () => _followingService.follow(payload),
      fallbackErrorCode: 'team_follow_failed',
      userMessage: 'Could not follow this team right now.',
    );
  }

  Future<void> unfollow() async {
    final payload = UnfollowPayloadModel(
      entityType: FollowEntityType.team,
      entityId: _teamId,
    );

    await ApiErrorHandler.handle<FollowingActionUiModel>(
      () => _followingService.unfollow(payload),
      fallbackErrorCode: 'team_unfollow_failed',
      userMessage: 'Could not unfollow this team right now.',
    );
  }

  void toggleAboutExpanded() {
    state.value = state.value.copyWith(
      isAboutExpanded: !state.value.isAboutExpanded,
    );
  }

  void selectSeason(String season) {
    if (season == state.value.selectedSeason) {
      return;
    }
    state.value = state.value.copyWith(selectedSeason: season);
    _loadSeasonScopedData();
  }

  void toggleTeamLeaguesExpanded() {
    state.value = state.value.copyWith(
      isTeamLeaguesExpanded: !state.value.isTeamLeaguesExpanded,
    );
  }

  void openCoachProfile(FootballTeamCoachModel coach) {
    final coachId = coach.id == null ? '' : coach.id.toString();
    final teamId = _resolveTeamIdForCoach(coach);

    if (coachId.isEmpty && teamId.isEmpty) {
      return;
    }

    final arguments = <String, dynamic>{};
    if (coachId.isNotEmpty) {
      arguments['coachId'] = coachId;
    }
    if (teamId.isNotEmpty) {
      arguments['teamId'] = teamId;
      final career = _coachCareerForTeam(coach, teamId);
      final fromDate = career?.start ?? '';
      final toDate = career?.end ?? '';
      if (fromDate.isNotEmpty) {
        arguments['fromDate'] = fromDate;
      }
      if (toDate.isNotEmpty) {
        arguments['toDate'] = toDate;
      }
    }

    Get.toNamed(AppRoutes.coachProfile, arguments: arguments);
  }

  void openPlayerProfile(FootballTeamPlayerItemModel player) {
    final playerId = player.player.id == null
        ? ''
        : player.player.id.toString();

    if (playerId.isEmpty) {
      return;
    }

    final teamId = _resolveTeamIdForPlayer(player);
    final teamName = state.value.team.name.trim();

    final arguments = <String, dynamic>{
      'playerId': playerId,
      'playerName': player.player.name,
      'season': _selectedSeasonYear.toString(),
    };

    if (teamId.isNotEmpty) {
      arguments['teamId'] = teamId;
    }

    if (teamName.isNotEmpty) {
      arguments['teamName'] = teamName;
    }

    Get.toNamed(AppRoutes.playerProfile, arguments: arguments);
  }

  void openMatchDetailsFromNextMatch(TeamProfileNextMatchUiModel match) {
    _openMatchDetails(
      fixtureId: match.fixtureId,
      scenario: 'upcoming',
      homeTeamId: match.homeTeam.teamId,
      awayTeamId: match.awayTeam.teamId,
      homeTeamName: match.homeTeam.name,
      awayTeamName: match.awayTeam.name,
    );
  }

  void openMatchDetailsFromFormResult(TeamProfileFormResultUiModel result) {
    _openMatchDetails(
      fixtureId: result.fixtureId,
      scenario: 'finished',
      homeTeamId: result.homeTeamId,
      awayTeamId: result.awayTeamId,
      homeTeamName: result.homeTeamName,
      awayTeamName: result.awayTeamName,
    );
  }

  void openLeagueDetails(FootballLeagueApiItemModel league) {
    if (league.league.id == null) {
      return;
    }

    Get.toNamed(
      AppRoutes.leagueDetails,
      arguments: LeaguesTopLeagueUiModel.fromFootballLeague(league),
    );
  }

  void openDomesticLeagueDetails() {
    final league = state.value.domesticLeague;
    if (league == null) {
      return;
    }

    openLeagueDetails(league);
  }

  List<FootballTeamPlayerItemModel> get topPlayers {
    final leagueId = state.value.domesticLeague?.league.id;
    final players = List<FootballTeamPlayerItemModel>.from(state.value.players);
    players.sort((left, right) {
      final leftStat = left.statisticForLeague(leagueId);
      final rightStat = right.statisticForLeague(leagueId);
      final leftRating = leftStat?.games.ratingValue ?? 0;
      final rightRating = rightStat?.games.ratingValue ?? 0;
      if (rightRating.compareTo(leftRating) != 0) {
        return rightRating.compareTo(leftRating);
      }
      final leftAppearances = leftStat?.games.appearences ?? 0;
      final rightAppearances = rightStat?.games.appearences ?? 0;
      return rightAppearances.compareTo(leftAppearances);
    });
    return players.take(3).toList(growable: false);
  }

  Map<String, List<FootballTeamPlayerItemModel>> get playersByPosition {
    final leagueId = state.value.domesticLeague?.league.id;
    final grouped = <String, List<FootballTeamPlayerItemModel>>{
      'Goalkeepers': <FootballTeamPlayerItemModel>[],
      'Defenders': <FootballTeamPlayerItemModel>[],
      'Midfielders': <FootballTeamPlayerItemModel>[],
      'Attackers': <FootballTeamPlayerItemModel>[],
      'Others': <FootballTeamPlayerItemModel>[],
    };

    for (final player in state.value.players) {
      final position =
          player.statisticForLeague(leagueId)?.games.position.toLowerCase() ??
          '';
      if (position.contains('goalkeeper')) {
        grouped['Goalkeepers']!.add(player);
      } else if (position.contains('defender')) {
        grouped['Defenders']!.add(player);
      } else if (position.contains('midfielder')) {
        grouped['Midfielders']!.add(player);
      } else if (position.contains('attacker') ||
          position.contains('forward')) {
        grouped['Attackers']!.add(player);
      } else {
        grouped['Others']!.add(player);
      }
    }

    grouped.removeWhere((_, value) => value.isEmpty);
    return grouped;
  }

  FootballPlayerStatisticModel? playerStatistic(
    FootballTeamPlayerItemModel player,
  ) {
    return player.statisticForLeague(state.value.domesticLeague?.league.id);
  }

  String _resolveTeamIdForCoach(FootballTeamCoachModel coach) {
    final stateTeamId = state.value.team.teamId.trim();
    if (stateTeamId.isNotEmpty) {
      return stateTeamId;
    }

    final coachTeamId = coach.team.id;
    return coachTeamId == null ? '' : coachTeamId.toString();
  }

  FootballCoachCareerModel? _coachCareerForTeam(
    FootballTeamCoachModel coach,
    String teamId,
  ) {
    final cleanTeamId = teamId.trim();
    if (cleanTeamId.isEmpty) {
      return null;
    }

    for (final entry in coach.career) {
      final entryTeamId = entry.team.id == null ? '' : entry.team.id.toString();
      if (entryTeamId == cleanTeamId) {
        return entry;
      }
    }

    return null;
  }

  String _resolveTeamIdForPlayer(FootballTeamPlayerItemModel player) {
    final stateTeamId = state.value.team.teamId.trim();
    if (stateTeamId.isNotEmpty) {
      return stateTeamId;
    }

    final statTeamId = playerStatistic(player)?.team.id;
    return statTeamId == null ? '' : statTeamId.toString();
  }

  String get domesticLeagueTitle {
    final name = state.value.domesticLeague?.league.name ?? '';
    return name.isEmpty ? 'League table' : name;
  }

  Future<void> loadMorePreviousMatches() async {
    final current = state.value;
    if (current.isPreviousMatchesLoading ||
        current.isPreviousMatchesLoadingMore) {
      return;
    }
    if (!current.canLoadMorePreviousMatches) {
      return;
    }

    await _loadPreviousFixtures(
      limit: _boundedLimit(current.visiblePreviousMatches + _matchesPageSize),
      isLoadMore: true,
    );
  }

  Future<void> loadMoreUpcomingMatches() async {
    final current = state.value;
    if (current.isUpcomingMatchesLoading ||
        current.isUpcomingMatchesLoadingMore) {
      return;
    }
    if (!current.canLoadMoreUpcomingMatches) {
      return;
    }

    await _loadUpcomingFixtures(
      limit: _boundedLimit(current.visibleUpcomingMatches + _matchesPageSize),
      isLoadMore: true,
    );
  }

  void loadMoreTrophies() {
    final current = state.value;
    if (!current.canLoadMoreTrophies) {
      return;
    }

    state.value = current.copyWith(
      visibleTrophies: current.visibleTrophies + 2,
    );
  }

  Future<void> _loadInitialData() async {
    await Future.wait(<Future<void>>[
      _loadTeamInfo(),
      _loadTeamAbout(),
      _loadUpcomingFixtures(limit: _matchesPageSize, isLoadMore: false),
      _loadPreviousFixtures(limit: _overviewPreviousLimit, isLoadMore: false),
      _loadTeamCoaches(),
      _loadTeamLeaguesAndStandings(),
      _loadTeamTrophies(),
    ]);
  }

  Future<void> _loadSeasonScopedData() async {
    state.value = state.value.copyWith(
      players: const <FootballTeamPlayerItemModel>[],
    );

    await Future.wait(<Future<void>>[
      _loadTeamLeaguesAndStandings(),
      _loadTeamTrophies(),
    ]);
  }

  Future<void> _loadTeamTrophies() async {
    state.value = state.value.copyWith(isTrophiesLoading: true);

    final response =
        await ApiErrorHandler.handle<FootballTeamTrophiesPreviewDataModel>(
          () => _service.fetchTeamTrophiesPreview(
            teamId: _teamId,
            fromSeason: 2000,
            toSeason: _selectedSeasonEndYear,
            page: 1,
            limit: 20,
          ),
          fallbackErrorCode: 'team_trophies_fetch_failed',
          userMessage: 'Unable to load team trophies right now.',
        );

    if (isClosed) return;

    if (!response.success || response.data == null) {
      state.value = state.value.copyWith(isTrophiesLoading: false);
      return;
    }

    final trophies = response.data!.items
        .map(_trophySectionFromApi)
        .where((item) => item.entries.isNotEmpty)
        .toList(growable: false);

    state.value = state.value.copyWith(
      isTrophiesLoading: false,
      trophies: trophies,
      visibleTrophies: 4,
    );
  }

  Future<void> _loadTeamPlayers({int? leagueId}) async {
    state.value = state.value.copyWith(isPlayersLoading: true);

    final response = await ApiErrorHandler.handle<FootballTeamPlayersDataModel>(
      () => _service.fetchTeamPlayers(
        teamId: _teamId,
        season: _selectedSeasonYear,
        leagueId: leagueId,
      ),
      fallbackErrorCode: 'team_players_fetch_failed',
      userMessage: 'Unable to load team players right now.',
    );

    if (isClosed) return;
    state.value = state.value.copyWith(isPlayersLoading: false);

    if (!response.success || response.data == null) {
      return;
    }

    state.value = state.value.copyWith(players: response.data!.response);
  }

  Future<void> _loadTeamCoaches() async {
    state.value = state.value.copyWith(isCoachesLoading: true);

    final response = await ApiErrorHandler.handle<FootballTeamCoachesDataModel>(
      () => _service.fetchTeamCoaches(_teamId),
      fallbackErrorCode: 'team_coaches_fetch_failed',
      userMessage: 'Unable to load team coach right now.',
    );

    if (isClosed) return;
    state.value = state.value.copyWith(isCoachesLoading: false);

    if (!response.success || response.data == null) {
      return;
    }

    final coach = _latestCoach(response.data!.response);
    state.value = state.value.copyWith(
      latestCoach: coach,
      coach: coach == null ? state.value.coach : _coachUiFromApi(coach),
    );
  }

  Future<void> _loadTeamLeaguesAndStandings() async {
    state.value = state.value.copyWith(
      isTeamLeaguesLoading: true,
      isStandingsLoading: true,
    );

    final response = await ApiErrorHandler.handle<FootballLeaguesDataModel>(
      () => _service.fetchTeamLeagues(
        teamId: _teamId,
        season: _selectedSeasonYear,
      ),
      fallbackErrorCode: 'team_leagues_fetch_failed',
      userMessage: 'Unable to load team leagues right now.',
    );

    if (isClosed) return;
    state.value = state.value.copyWith(isTeamLeaguesLoading: false);

    if (!response.success || response.data == null) {
      state.value = state.value.copyWith(isStandingsLoading: false);
      return;
    }

    final leagues = response.data!.response;
    final domesticLeague = _firstDomesticLeague(leagues);
    final overview = state.value.overview.copyWith(
      leagues: leagues.map(_teamLeagueUiFromApi).toList(growable: false),
    );
    state.value = state.value.copyWith(
      teamLeagues: leagues,
      domesticLeague: domesticLeague,
      overview: overview,
      isTeamLeaguesExpanded: false,
    );

    final leagueId = domesticLeague?.league.id;
    await _loadTeamPlayers(leagueId: leagueId);

    if (leagueId == null) {
      state.value = state.value.copyWith(
        isStandingsLoading: false,
        standingRows: <FootballStandingRowModel>[],
        standings: <TeamProfileStandingsRowUiModel>[],
      );
      return;
    }

    final standingsResponse =
        await ApiErrorHandler.handle<FootballStandingsDataModel>(
          () => _service.fetchStandings(
            leagueId: leagueId,
            season: _selectedSeasonYear,
          ),
          fallbackErrorCode: 'team_standings_fetch_failed',
          userMessage: 'Unable to load standings right now.',
        );

    if (isClosed) return;
    state.value = state.value.copyWith(isStandingsLoading: false);

    if (!standingsResponse.success || standingsResponse.data == null) {
      return;
    }

    final rows = standingsResponse.data!.response.isEmpty
        ? <FootballStandingRowModel>[]
        : standingsResponse.data!.response.first.standings
              .expand((group) => group)
              .toList(growable: false);

    state.value = state.value.copyWith(
      standingRows: rows,
      standings: rows.map(_standingUiFromApi).toList(growable: false),
    );
  }

  Future<void> _loadTeamInfo() async {
    state.value = state.value.copyWith(isTeamInfoLoading: true);

    final response = await ApiErrorHandler.handle<FootballTeamInfoDataModel>(
      () => _service.fetchTeamInfo(_teamId),
      fallbackErrorCode: 'team_info_fetch_failed',
      userMessage: 'Unable to load team information right now.',
    );

    if (isClosed) return;
    state.value = state.value.copyWith(isTeamInfoLoading: false);

    final data = response.data;
    if (!response.success || data == null || data.response.isEmpty) {
      return;
    }

    final item = data.response.first;
    final team = item.team;
    final venue = item.venue;
    final resolvedTeamId = '${team.id ?? _teamId}';
    final teamUi = TeamProfileTeamUiModel(
      teamId: resolvedTeamId,
      name: team.name.isEmpty ? state.value.team.name : team.name,
      country: team.country,
      badgeSeed: _seed(team.code.isNotEmpty ? team.code : team.name),
      badgeColor: _badgeColor(team.id),
      logoUrl: team.logo,
    );

    if (data.follow.entityId.isNotEmpty || resolvedTeamId.isNotEmpty) {
      _followingService.setLocalFollowState(
        FollowEntityType.team,
        data.follow.entityId.isNotEmpty ? data.follow.entityId : resolvedTeamId,
        data.follow.isFollowed,
      );
    }

    final overview = state.value.overview.copyWith(
      venue: TeamProfileVenueUiModel(
        stadiumName: venue.name,
        city: venue.city,
        capacity: venue.capacity == null ? '-' : '${venue.capacity}',
        surface: venue.surface.isEmpty ? '-' : venue.surface,
        opened: team.founded == null ? '-' : '${team.founded}',
        imageUrl: venue.image,
        address: venue.address,
      ),
    );

    state.value = state.value.copyWith(
      team: teamUi,
      overview: overview,
      isFollowing: data.follow.isFollowed,
    );
    _syncFollowingState();
  }

  Future<void> _loadTeamAbout() async {
    final response = await ApiErrorHandler.handle<FootballTeamAboutDataModel>(
      () => _service.fetchTeamAbout(_teamId),
      fallbackErrorCode: 'team_about_fetch_failed',
      userMessage: 'Unable to load team about information right now.',
    );

    if (isClosed || !response.success || response.data == null) {
      return;
    }

    final about = response.data!;
    state.value = state.value.copyWith(
      overview: state.value.overview.copyWith(
        aboutText: about.about.trim().isEmpty
            ? state.value.overview.aboutText
            : about.about.trim(),
      ),
    );
  }

  Future<void> _loadUpcomingFixtures({
    required int limit,
    required bool isLoadMore,
  }) async {
    if (isLoadMore) {
      state.value = state.value.copyWith(isUpcomingMatchesLoadingMore: true);
    } else {
      state.value = state.value.copyWith(isUpcomingMatchesLoading: true);
    }

    final previousCount = state.value.upcomingMatches.length;
    final response = await ApiErrorHandler.handle<FootballFixturesDataModel>(
      () => _service.fetchUpcomingFixtures(teamId: _teamId, next: limit),
      fallbackErrorCode: 'team_upcoming_fixtures_fetch_failed',
      userMessage: 'Unable to load upcoming fixtures right now.',
    );

    if (isClosed) return;

    if (isLoadMore) {
      state.value = state.value.copyWith(isUpcomingMatchesLoadingMore: false);
    } else {
      state.value = state.value.copyWith(isUpcomingMatchesLoading: false);
    }

    if (!response.success || response.data == null) {
      return;
    }

    final fixtures = response.data!.response;
    final rows = fixtures
        .map((fixture) => _matchRowFromFixture(fixture, isUpcoming: true))
        .toList(growable: false);

    final overview = state.value.overview.copyWith(
      nextMatches: rows.take(2).map(_nextMatchFromRow).toList(growable: false),
    );

    state.value = state.value.copyWith(
      overview: overview,
      upcomingMatches: rows,
      visibleUpcomingMatches: _minInt(rows.length, limit),
      canLoadMoreUpcomingMatchesFromApi:
          rows.length >= limit && rows.length > previousCount,
    );
  }

  Future<void> _loadPreviousFixtures({
    required int limit,
    required bool isLoadMore,
  }) async {
    if (isLoadMore) {
      state.value = state.value.copyWith(isPreviousMatchesLoadingMore: true);
    } else {
      state.value = state.value.copyWith(isPreviousMatchesLoading: true);
    }

    final previousCount = state.value.previousMatches.length;
    final response = await ApiErrorHandler.handle<FootballFixturesDataModel>(
      () => _service.fetchPreviousFixtures(teamId: _teamId, last: limit),
      fallbackErrorCode: 'team_previous_fixtures_fetch_failed',
      userMessage: 'Unable to load previous fixtures right now.',
    );

    if (isClosed) return;

    if (isLoadMore) {
      state.value = state.value.copyWith(isPreviousMatchesLoadingMore: false);
    } else {
      state.value = state.value.copyWith(isPreviousMatchesLoading: false);
    }

    if (!response.success || response.data == null) {
      return;
    }

    final fixtures = response.data!.response;
    final rows = fixtures
        .map((fixture) => _matchRowFromFixture(fixture, isUpcoming: false))
        .toList(growable: false);
    final formResults = fixtures
        .take(_overviewPreviousLimit)
        .map(_formResultFromFixture)
        .toList(growable: false);

    final overview = state.value.overview.copyWith(
      leftResults: formResults.take(3).toList(growable: false),
      rightResults: formResults.skip(3).take(3).toList(growable: false),
    );

    state.value = state.value.copyWith(
      overview: overview,
      previousMatches: rows,
      visiblePreviousMatches: isLoadMore
          ? _minInt(rows.length, limit)
          : _minInt(rows.length, _matchesPageSize),
      canLoadMorePreviousMatchesFromApi:
          rows.length >= limit && rows.length > previousCount,
    );
  }

  int get _selectedSeasonYear {
    final firstPart = state.value.selectedSeason.split('/').first.trim();
    return int.tryParse(firstPart) ?? DateTime.now().year;
  }

  int get _selectedSeasonEndYear {
    final parts = state.value.selectedSeason.split('/');
    if (parts.length > 1) {
      return int.tryParse(parts.last.trim()) ?? _selectedSeasonYear;
    }
    return _selectedSeasonYear;
  }

  FootballLeagueApiItemModel? _firstDomesticLeague(
    List<FootballLeagueApiItemModel> leagues,
  ) {
    for (final item in leagues) {
      if (item.country.name.toLowerCase() != 'world' &&
          item.league.type.toLowerCase() == 'league') {
        return item;
      }
    }
    return null;
  }

  FootballTeamCoachModel? _latestCoach(List<FootballTeamCoachModel> coaches) {
    FootballTeamCoachModel? selected;
    DateTime? selectedStart;

    for (final coach in coaches) {
      for (final career in coach.career) {
        if ('${career.team.id ?? ''}' != _teamId || career.end != null) {
          continue;
        }
        final start = career.startDate ?? DateTime(1900);
        if (selected == null ||
            selectedStart == null ||
            start.isAfter(selectedStart)) {
          selected = coach;
          selectedStart = start;
        }
      }
    }

    if (selected != null) return selected;

    for (final coach in coaches) {
      for (final career in coach.career) {
        if ('${career.team.id ?? ''}' != _teamId) continue;
        final start = career.startDate ?? DateTime(1900);
        if (selected == null ||
            selectedStart == null ||
            start.isAfter(selectedStart)) {
          selected = coach;
          selectedStart = start;
        }
      }
    }

    return selected ?? (coaches.isEmpty ? null : coaches.last);
  }

  TeamProfileSquadPersonUiModel _coachUiFromApi(FootballTeamCoachModel coach) {
    return TeamProfileSquadPersonUiModel(
      name: coach.name,
      countryFlag: '',
      countryName: coach.nationality ?? '-',
      shirtNumber: '-',
      age: coach.age == null ? '-' : '${coach.age}',
      badgeSeed: _seed(coach.name),
      badgeColor: _badgeColor(coach.id),
    );
  }

  TeamProfileTrophySectionUiModel _trophySectionFromApi(
    FootballTeamTrophyPreviewItemModel item,
  ) {
    final entries = <TeamProfileTrophyEntryUiModel>[];
    if (item.winner.count > 0 || item.winner.seasons.isNotEmpty) {
      entries.add(
        TeamProfileTrophyEntryUiModel(
          count: '${item.winner.count}',
          label: 'Winner',
          years: _seasonListLabel(item.winner.seasons),
        ),
      );
    }
    if (item.runnerUp.count > 0 || item.runnerUp.seasons.isNotEmpty) {
      entries.add(
        TeamProfileTrophyEntryUiModel(
          count: '${item.runnerUp.count}',
          label: 'Runner-up',
          years: _seasonListLabel(item.runnerUp.seasons),
        ),
      );
    }

    return TeamProfileTrophySectionUiModel(
      title: item.league.name.isEmpty ? 'Competition' : item.league.name,
      badgeSeed: _seed(item.league.name),
      badgeColor: _badgeColor(item.league.id),
      logoUrl: item.league.logo,
      entries: entries,
    );
  }

  String _seasonListLabel(List<String> seasons) {
    if (seasons.isEmpty) return '-';
    return seasons.join(', ');
  }

  TeamProfileLeagueItemUiModel _teamLeagueUiFromApi(
    FootballLeagueApiItemModel item,
  ) {
    return TeamProfileLeagueItemUiModel(
      title: item.league.name,
      seasonLabel: _leagueSeasonLabel(item),
      badgeSeed: _seed(item.league.name),
      badgeColor: _badgeColor(item.league.id),
      logoUrl: item.league.logo,
    );
  }

  String _leagueSeasonLabel(FootballLeagueApiItemModel item) {
    final year = item.currentSeasonYear;
    final country = item.country.name;
    if (year == null && country.isEmpty) return '-';
    if (country.isEmpty) return '$year';
    if (year == null) return country;
    return '$country • $year';
  }

  TeamProfileStandingsRowUiModel _standingUiFromApi(
    FootballStandingRowModel row,
  ) {
    final goalsFor = row.all.goals.goalsFor ?? 0;
    final goalsAgainst = row.all.goals.against ?? 0;
    return TeamProfileStandingsRowUiModel(
      rank: '${row.rank ?? '-'}',
      teamName: row.team.name,
      badgeSeed: _seed(row.team.name),
      badgeColor: _badgeColor(row.team.id),
      played: '${row.all.played ?? '-'}',
      plusMinus: '$goalsFor-$goalsAgainst',
      goalDifference: row.goalsDiff == null ? '-' : '${row.goalsDiff}',
      points: '${row.points ?? '-'}',
      logoUrl: row.team.logo,
    );
  }

  TeamProfileMatchRowUiModel _matchRowFromFixture(
    FootballFixtureModel fixture, {
    required bool isUpcoming,
  }) {
    final kickoffAt = fixture.fixture.kickoffAt;
    return TeamProfileMatchRowUiModel(
      fixtureId: '${fixture.fixture.id ?? ''}',
      dateLabel: _dateLabel(kickoffAt),
      competitionLabel: fixture.league.name,
      leagueLogoUrl: fixture.league.logo ?? '',
      homeTeam: _teamFromFootball(fixture.teams.home),
      awayTeam: _teamFromFootball(fixture.teams.away),
      centerLabel: isUpcoming ? _timeLabel(kickoffAt) : _scoreLabel(fixture),
      isUpcoming: isUpcoming,
    );
  }

  TeamProfileNextMatchUiModel _nextMatchFromRow(
    TeamProfileMatchRowUiModel row,
  ) {
    return TeamProfileNextMatchUiModel(
      fixtureId: row.fixtureId,
      competitionLabel: row.competitionLabel,
      timeLabel: row.centerLabel,
      statusLabel: row.dateLabel,
      homeTeam: row.homeTeam,
      awayTeam: row.awayTeam,
    );
  }

  TeamProfileFormResultUiModel _formResultFromFixture(
    FootballFixtureModel fixture,
  ) {
    final homeId = '${fixture.teams.home.id ?? ''}';
    final awayId = '${fixture.teams.away.id ?? ''}';
    final fixtureId = '${fixture.fixture.id ?? ''}';
    final isHomeTeam = homeId == _teamId;
    final isAwayTeam = awayId == _teamId;
    final homeGoals = fixture.goals.home ?? fixture.score.fulltime.home;
    final awayGoals = fixture.goals.away ?? fixture.score.fulltime.away;
    final score = _scoreLabel(fixture);

    bool isDraw = false;
    bool isPositive = false;
    String logoUrl = fixture.league.logo ?? '';
    String teamName = fixture.league.name;

    if (isHomeTeam || isAwayTeam) {
      final ownGoals = isHomeTeam ? homeGoals : awayGoals;
      final opponentGoals = isHomeTeam ? awayGoals : homeGoals;
      isDraw =
          ownGoals != null &&
          opponentGoals != null &&
          ownGoals == opponentGoals;
      isPositive =
          ownGoals != null && opponentGoals != null && ownGoals > opponentGoals;
      final opponent = isHomeTeam ? fixture.teams.away : fixture.teams.home;
      logoUrl = opponent.logo ?? '';
      teamName = opponent.name;
    } else {
      isDraw =
          fixture.teams.home.winner == null &&
          fixture.teams.away.winner == null;
      isPositive =
          fixture.teams.home.winner == true ||
          fixture.teams.away.winner == true;
      logoUrl = fixture.teams.home.logo ?? fixture.teams.away.logo ?? '';
      teamName = fixture.teams.home.name;
    }

    return TeamProfileFormResultUiModel(
      scoreLabel: score,
      isPositive: isPositive,
      isDraw: isDraw,
      fixtureId: fixtureId,
      homeTeamId: homeId,
      awayTeamId: awayId,
      homeTeamName: fixture.teams.home.name,
      awayTeamName: fixture.teams.away.name,
      logoUrl: logoUrl,
      homeLogoUrl: fixture.teams.home.logo ?? '',
      awayLogoUrl: fixture.teams.away.logo ?? '',
      teamName: teamName,
    );
  }

  void _openMatchDetails({
    required String fixtureId,
    required String scenario,
    String homeTeamId = '',
    String awayTeamId = '',
    String homeTeamName = '',
    String awayTeamName = '',
  }) {
    final safeFixtureId = fixtureId.trim();
    if (safeFixtureId.isEmpty) {
      return;
    }

    final safeScenario = scenario.trim().isEmpty
        ? 'finished'
        : scenario.trim().toLowerCase();

    final arguments = <String, dynamic>{
      'scenario': safeScenario,
      'fixtureId': safeFixtureId,
    };

    final safeHomeTeamId = homeTeamId.trim();
    if (safeHomeTeamId.isNotEmpty) {
      arguments['homeTeamId'] = safeHomeTeamId;
    }

    final safeAwayTeamId = awayTeamId.trim();
    if (safeAwayTeamId.isNotEmpty) {
      arguments['awayTeamId'] = safeAwayTeamId;
    }

    final safeHomeTeamName = homeTeamName.trim();
    if (safeHomeTeamName.isNotEmpty) {
      arguments['homeTeamName'] = safeHomeTeamName;
    }

    final safeAwayTeamName = awayTeamName.trim();
    if (safeAwayTeamName.isNotEmpty) {
      arguments['awayTeamName'] = safeAwayTeamName;
    }

    Get.toNamed(AppRoutes.matchDetails, arguments: arguments);
  }

  TeamProfileTeamUiModel _teamFromFootball(FootballTeamModel team) {
    return TeamProfileTeamUiModel(
      teamId: '${team.id ?? ''}',
      name: team.name,
      country: '',
      badgeSeed: _seed(team.name),
      badgeColor: _badgeColor(team.id),
      logoUrl: team.logo ?? '',
    );
  }

  void _readArguments() {
    final argument = Get.arguments;
    if (argument is String) {
      final raw = argument.trim();
      if (_looksLikeTeamId(raw)) {
        _teamId = raw;
      } else {
        initialTabIndex = _tabIndexFrom(raw);
      }
      return;
    }

    if (argument is Map) {
      initialTabIndex = _tabIndexFrom(argument['tab']?.toString() ?? '');
      _teamId = _argumentString(argument, const <String>[
        'teamId',
        'team_id',
        'id',
      ], _teamId);
    }
  }

  void _syncFollowingState() {
    state.value = state.value.copyWith(
      isFollowing: _followingService.isFollowing(
        FollowEntityType.team,
        _teamId,
      ),
    );
  }

  bool _looksLikeTeamId(String value) {
    return int.tryParse(value) != null;
  }

  String _argumentString(
    Map<dynamic, dynamic> argument,
    List<String> keys,
    String fallback,
  ) {
    for (final key in keys) {
      final value = argument[key]?.toString().trim();
      if (value != null && value.isNotEmpty) {
        return value;
      }
    }
    return fallback;
  }

  int _tabIndexFrom(String value) {
    switch (value.toLowerCase()) {
      case 'table':
        return 1;
      case 'matches':
        return 2;
      case 'squad':
      case 'squads':
        return 3;
      case 'trophies':
        return 4;
      default:
        return 0;
    }
  }

  int _boundedLimit(int value) {
    if (value < _matchesPageSize) return _matchesPageSize;
    if (value > 100) return 100;
    return value;
  }

  int _minInt(int left, int right) {
    return left < right ? left : right;
  }

  String _scoreLabel(FootballFixtureModel fixture) {
    final home = fixture.goals.home ?? fixture.score.fulltime.home;
    final away = fixture.goals.away ?? fixture.score.fulltime.away;
    if (home == null || away == null) {
      return '-';
    }
    return '$home - $away';
  }

  String _dateLabel(DateTime? date) {
    if (date == null) return '-';
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final target = DateTime(date.year, date.month, date.day);
    final diff = target.difference(today).inDays;
    if (diff == 0) return 'Today';
    if (diff == 1) return 'Tomorrow';
    if (diff == -1) return 'Yesterday';
    return '${date.day} ${_monthName(date.month)}';
  }

  String _timeLabel(DateTime? date) {
    if (date == null) return '-';
    final hour = date.hour.toString().padLeft(2, '0');
    final minute = date.minute.toString().padLeft(2, '0');
    return '$hour:$minute';
  }

  String _monthName(int month) {
    const names = <String>[
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    if (month < 1 || month > 12) return '';
    return names[month - 1];
  }

  String _seed(String value) {
    final clean = value.trim();
    if (clean.isEmpty) return '?';
    final parts = clean.split(RegExp(r'\s+'));
    if (parts.length == 1) {
      return clean
          .substring(0, clean.length < 3 ? clean.length : 3)
          .toUpperCase();
    }
    return parts.take(3).map((part) => part[0]).join().toUpperCase();
  }

  Color _badgeColor(int? id) {
    const colors = <Color>[
      Color(0xFFC13329),
      Color(0xFF2F6FE4),
      Color(0xFF0E8B67),
      Color(0xFF8B1D2C),
      Color(0xFF274C93),
      Color(0xFF6B1CC2),
    ];
    if (id == null) return colors.first;
    return colors[id.abs() % colors.length];
  }

  static const TeamProfileTeamUiModel _defaultTeam = TeamProfileTeamUiModel(
    teamId: '',
    name: '',
    country: '',
    badgeSeed: '',
    badgeColor: Colors.transparent,
    logoUrl: '',
  );

  static const List<String> _seasons = <String>['2025', '2024', '2023'];

  static const TeamProfileOverviewUiModel _overview =
      TeamProfileOverviewUiModel(
        nextMatches: <TeamProfileNextMatchUiModel>[],
        leftResults: <TeamProfileFormResultUiModel>[],
        rightResults: <TeamProfileFormResultUiModel>[],
        topPlayers: <TeamProfileTopPlayerUiModel>[],
        leagues: <TeamProfileLeagueItemUiModel>[],
        rankings: <TeamProfileRankingItemUiModel>[],
        venue: TeamProfileVenueUiModel(
          stadiumName: '',
          city: '',
          capacity: '',
          surface: '',
          opened: '',
        ),
        aboutText: '',
      );

  static const TeamProfileViewModel _initialState = TeamProfileViewModel(
    team: _defaultTeam,
    isFollowing: false,
    isTeamInfoLoading: true,
    isOverviewFixturesLoading: true,
    isPreviousMatchesLoading: true,
    isUpcomingMatchesLoading: true,
    isPlayersLoading: true,
    isTeamLeaguesLoading: true,
    isStandingsLoading: true,
    isCoachesLoading: true,
    seasons: _seasons,
    selectedSeason: '2025/2026',
    overview: _overview,
    standings: <TeamProfileStandingsRowUiModel>[],
    previousMatches: <TeamProfileMatchRowUiModel>[],
    upcomingMatches: <TeamProfileMatchRowUiModel>[],
    visiblePreviousMatches: 5,
    visibleUpcomingMatches: 5,
    trophies: <TeamProfileTrophySectionUiModel>[],
    visibleTrophies: 4,
  );
}
