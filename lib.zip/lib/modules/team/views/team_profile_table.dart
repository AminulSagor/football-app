import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../../core/themes/app_text_styles.dart';
import '../team_profile_controller.dart';
import '../team_profile_model.dart';

class TeamProfileTablePage extends GetView<TeamProfileController> {
  const TeamProfileTablePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final rows = controller.state.value.standings;

      return ListView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.fromLTRB(16.w, 12.h, 16.w, 28.h),
        children: [
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22.r),
              gradient: const LinearGradient(
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
                colors: [Color(0xFF12201D), Color(0xFF1F2A28)],
              ),
              border: Border.all(color: Colors.white.withAlpha(10), width: 1.w),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(22.r),
              child: Column(
                children: [
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 14.h),
                    color: Colors.white.withAlpha(4),
                    child: Row(
                      children: const [
                        _HeaderLabel(width: 28, text: '#'),
                        Expanded(flex: 8, child: _HeaderLabel(text: 'TEAM')),
                        Expanded(flex: 2, child: _HeaderLabel(text: 'PL', align: TextAlign.center)),
                        Expanded(flex: 2, child: _HeaderLabel(text: 'GD', align: TextAlign.center)),
                        Expanded(flex: 2, child: _HeaderLabel(text: 'PTS', align: TextAlign.right)),
                      ],
                    ),
                  ),
                  for (var index = 0; index < rows.length; index++)
                    _StandingsTableRow(
                      item: rows[index],
                      showDivider: index != rows.length - 1,
                    ),
                ],
              ),
            ),
          ),
          SizedBox(height: 18.h),
          Wrap(
            spacing: 18.w,
            runSpacing: 12.h,
            children: const [
              _LegendItem(color: Color(0xFF16C79A), label: 'CHAMPIONS LEAGUE'),
              _LegendItem(color: Color(0xFF2F6FE4), label: 'EUROPA LEAGUE'),
              _LegendItem(color: Color(0xFFFF6E6E), label: 'RELEGATION'),
            ],
          ),
        ],
      );
    });
  }
}

class _StandingsTableRow extends StatelessWidget {
  final TeamProfileStandingsRowUiModel item;
  final bool showDivider;

  const _StandingsTableRow({
    required this.item,
    required this.showDivider,
  });

  @override
  Widget build(BuildContext context) {
    final rank = int.tryParse(item.rank) ?? 0;

    return Container(
      height: 65.h,
      decoration: BoxDecoration(
        color: Colors.white.withAlpha(4),
        border: showDivider
            ? Border(
                bottom: BorderSide(
                  color: Colors.white.withAlpha(6),
                  width: 1.w,
                ),
              )
            : null,
      ),
      child: Row(
        children: [
          Container(width: 3.w, color: _zoneColor(rank)),
          Expanded(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 12.w),
              child: Row(
                children: [
                  SizedBox(
                    width: 20.w,
                    child: Text(
                      item.rank,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: AppTextStyles.sizeBodySmall.sp,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  SizedBox(width: 10.w),
                  Expanded(
                    flex: 8,
                    child: Row(
                      children: [
                        Container(
                          width: 24.r,
                          height: 24.r,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(7.r),
                            color: item.badgeColor,
                            border: Border.all(
                              color: Colors.white.withAlpha(28),
                              width: .8.w,
                            ),
                          ),
                          alignment: Alignment.center,
                          child: Text(
                            item.badgeSeed,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 6.4.sp,
                              fontWeight: FontWeight.w800,
                              height: 1,
                            ),
                          ),
                        ),
                        SizedBox(width: 12.w),
                        Expanded(
                          child: Text(
                            item.teamName,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: AppTextStyles.sizeBody.sp,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      item.played,
                      textAlign: TextAlign.center,
                      style: _valueStyle(),
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      item.goalDifference,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: _goalDifferenceColor(item.goalDifference),
                        fontSize: AppTextStyles.sizeBody.sp,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      item.points,
                      textAlign: TextAlign.right,
                      style: TextStyle(
                        color: rank <= 5 ? const Color(0xFF00B98B) : Colors.white,
                        fontSize: AppTextStyles.sizeHeading.sp,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Color _zoneColor(int rank) {
    if (rank >= 1 && rank <= 5) {
      return const Color(0xFF16C79A);
    }
    if (rank >= 6 && rank <= 9) {
      return const Color(0xFF2F6FE4);
    }
    if (rank >= 18) {
      return const Color(0xFFFF6E6E);
    }
    return Colors.transparent;
  }

  Color _goalDifferenceColor(String value) {
    return value.startsWith('-')
        ? const Color(0xFFFF6E6E)
        : const Color(0xFF39E0B3);
  }

  TextStyle _valueStyle() {
    return TextStyle(
      color: Colors.white.withAlpha(180),
      fontSize: AppTextStyles.sizeBody.sp,
      fontWeight: FontWeight.w500,
    );
  }
}

class _HeaderLabel extends StatelessWidget {
  final String text;
  final double? width;
  final TextAlign align;

  const _HeaderLabel({
    required this.text,
    this.width,
    this.align = TextAlign.left,
  });

  @override
  Widget build(BuildContext context) {
    final label = Text(
      text,
      textAlign: align,
      style: TextStyle(
        color: Colors.white.withAlpha(82),
        fontSize: AppTextStyles.sizeOverline.sp,
        fontWeight: FontWeight.w700,
        letterSpacing: 1.25,
      ),
    );

    if (width == null) {
      return label;
    }

    return SizedBox(width: width!.w, child: label);
  }
}

class _LegendItem extends StatelessWidget {
  final Color color;
  final String label;

  const _LegendItem({
    required this.color,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 8.r,
          height: 8.r,
          decoration: BoxDecoration(shape: BoxShape.circle, color: color),
        ),
        SizedBox(width: 8.w),
        Text(
          label,
          style: TextStyle(
            color: Colors.white.withAlpha(88),
            fontSize: AppTextStyles.sizeOverline.sp,
            fontWeight: FontWeight.w700,
            letterSpacing: 1.25,
          ),
        ),
      ],
    );
  }
}
