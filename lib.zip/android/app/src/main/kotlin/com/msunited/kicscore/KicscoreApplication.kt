package com.msunited.kicscore

import android.app.Application
import com.facebook.FacebookSdk

class KicscoreApplication : Application() {
    @Suppress("DEPRECATION")
    override fun onCreate() {
        super.onCreate()

        if (!FacebookSdk.isInitialized()) {
            FacebookSdk.sdkInitialize(applicationContext)
        }
    }
}
